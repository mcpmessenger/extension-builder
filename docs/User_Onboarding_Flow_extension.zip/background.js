// Background script for workflow extension
chrome.runtime.onInstalled.addListener(() => {
  console.log('Workflow extension installed');
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'startWorkflow') {
    console.log('Starting workflow');
  } else if (request.action === 'resetWorkflow') {
    console.log('Resetting workflow');
  }
});
