// Generated Extension: User Onboarding Flow
// This extension provides guided workflow steps

const WORKFLOW_DATA = {
  "id": "1",
  "name": "User Onboarding Flow",
  "description": "Guide new users through account setup and first actions",
  "targetUrl": "https://example.com",
  "steps": []
};

class WorkflowGuide {
  constructor() {
    this.currentStep = 0;
    this.steps = WORKFLOW_DATA.steps;
    this.overlay = null;
    this.tooltip = null;
    this.highlight = null;
    this.init();
  }

  init() {
    // Check if workflow has been completed
    chrome.storage.local.get(['workflowCompleted'], (result) => {
      if (!result.workflowCompleted) {
        this.start();
      }
    });

    // Listen for messages from background script
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'startWorkflow') {
        this.start();
      } else if (request.action === 'resetWorkflow') {
        this.reset();
      }
    });
  }

  start() {
    if (this.steps.length === 0) return;
    this.showStep(0);
  }

  showStep(index) {
    if (index >= this.steps.length) {
      this.complete();
      return;
    }

    this.currentStep = index;
    const step = this.steps[index];

    // Remove existing overlay and tooltip
    this.cleanup();

    // Wait for element to be available
    this.waitForElement(step.selector, (element) => {
      this.highlightElement(element, step);
      this.showTooltip(element, step);
    });
  }

  waitForElement(selector, callback, timeout = 5000) {
    const startTime = Date.now();
    
    const checkElement = () => {
      const element = document.querySelector(selector);
      if (element) {
        callback(element);
      } else if (Date.now() - startTime < timeout) {
        setTimeout(checkElement, 100);
      } else {
        console.warn('Element not found:', selector);
        this.showTooltip(document.body, this.steps[this.currentStep]);
      }
    };
    
    checkElement();
  }

  highlightElement(element, step) {
    // Create overlay
    this.overlay = document.createElement('div');
    this.overlay.className = 'workflow-overlay';
    document.body.appendChild(this.overlay);

    // Create highlight
    const rect = element.getBoundingClientRect();
    const highlight = document.createElement('div');
    highlight.className = 'workflow-highlight';
    highlight.style.top = rect.top + window.scrollY + 'px';
    highlight.style.left = rect.left + window.scrollX + 'px';
    highlight.style.width = rect.width + 'px';
    highlight.style.height = rect.height + 'px';
    document.body.appendChild(highlight);
    this.highlight = highlight;
  }

  showTooltip(element, step) {
    const rect = element.getBoundingClientRect();
    
    this.tooltip = document.createElement('div');
    this.tooltip.className = 'workflow-tooltip workflow-tooltip-' + step.position;
    
    this.tooltip.innerHTML = `
      <div class="workflow-tooltip-header">
        <span class="workflow-tooltip-progress">Step ${this.currentStep + 1} of ${this.steps.length}</span>
        <button class="workflow-tooltip-close" onclick="window.workflowGuide.skip()">&times;</button>
      </div>
      <h3 class="workflow-tooltip-title">${step.title}</h3>
      <p class="workflow-tooltip-description">${step.description}</p>
      ${step.screenshot ? `<img src="${step.screenshot}" class="workflow-tooltip-screenshot" />` : ''}
      <div class="workflow-tooltip-actions">
        ${this.currentStep > 0 ? '<button class="workflow-btn workflow-btn-secondary" onclick="window.workflowGuide.previous()">Previous</button>' : ''}
        <button class="workflow-btn workflow-btn-primary" onclick="window.workflowGuide.next()">
          ${this.currentStep === this.steps.length - 1 ? 'Finish' : 'Next'}
        </button>
      </div>
    `;

    document.body.appendChild(this.tooltip);
    this.positionTooltip(element, step.position);
  }

  positionTooltip(element, position) {
    const rect = element.getBoundingClientRect();
    const tooltipRect = this.tooltip.getBoundingClientRect();
    const padding = 16;

    let top, left;

    switch (position) {
      case 'top':
        top = rect.top + window.scrollY - tooltipRect.height - padding;
        left = rect.left + window.scrollX + (rect.width - tooltipRect.width) / 2;
        break;
      case 'bottom':
        top = rect.bottom + window.scrollY + padding;
        left = rect.left + window.scrollX + (rect.width - tooltipRect.width) / 2;
        break;
      case 'left':
        top = rect.top + window.scrollY + (rect.height - tooltipRect.height) / 2;
        left = rect.left + window.scrollX - tooltipRect.width - padding;
        break;
      case 'right':
        top = rect.top + window.scrollY + (rect.height - tooltipRect.height) / 2;
        left = rect.right + window.scrollX + padding;
        break;
    }

    this.tooltip.style.top = Math.max(padding, top) + 'px';
    this.tooltip.style.left = Math.max(padding, left) + 'px';
  }

  next() {
    this.showStep(this.currentStep + 1);
  }

  previous() {
    if (this.currentStep > 0) {
      this.showStep(this.currentStep - 1);
    }
  }

  skip() {
    this.cleanup();
    chrome.storage.local.set({ workflowCompleted: true });
  }

  complete() {
    this.cleanup();
    chrome.storage.local.set({ workflowCompleted: true });
    
    // Show completion message
    const completion = document.createElement('div');
    completion.className = 'workflow-completion';
    completion.innerHTML = `
      <div class="workflow-completion-content">
        <h3>Workflow Complete!</h3>
        <p>You've completed the guided tour.</p>
        <button class="workflow-btn workflow-btn-primary" onclick="this.parentElement.parentElement.remove()">Close</button>
      </div>
    `;
    document.body.appendChild(completion);
    
    setTimeout(() => {
      completion.remove();
    }, 5000);
  }

  cleanup() {
    if (this.overlay) {
      this.overlay.remove();
      this.overlay = null;
    }
    if (this.highlight) {
      this.highlight.remove();
      this.highlight = null;
    }
    if (this.tooltip) {
      this.tooltip.remove();
      this.tooltip = null;
    }
  }

  reset() {
    chrome.storage.local.remove('workflowCompleted');
    this.start();
  }
}

// Initialize workflow guide
window.workflowGuide = new WorkflowGuide();
